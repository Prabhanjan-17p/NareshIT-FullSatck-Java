import { BrowserRouter, Route, Routes } from "react-router-dom";
import { FakestoreHome } from "./fakestore-home";
import { FakestoreProducts } from "./fakestore-products";
import { FakestoreDetails } from "./fakestore-details";

export function FakestoreIndex(){
    return(
        <div className="container-fluid">
            <BrowserRouter>
                <header className="border mt-3 border-1 p-2">
                    <h1 className="text-center">Fakestore</h1>
                </header>
                <section className="mt-4">
                  <Routes>
                      <Route path="/" element={<FakestoreHome />} />
                      <Route path="products/:category" element={<FakestoreProducts />}>
                            <Route path="details/:id" element={<FakestoreDetails />} />
                      </Route>
                  </Routes>
                </section>
            </BrowserRouter>
        </div>
    )
}