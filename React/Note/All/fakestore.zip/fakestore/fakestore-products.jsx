import axios from "axios";
import { useEffect, useState } from "react";
import { Link, Outlet, useParams } from "react-router-dom";


export function FakestoreProducts(){


    const [products, setProducts] = useState([{id:0, title:'', price:0, category:'', description:'', image:'', rating:{rate:0, count:0}}]);

    let params = useParams();

    useEffect(()=>{

        axios.get(`https://fakestoreapi.com/products/category/${params.category}`)
        .then(response=>{
            setProducts(response.data);
        })

    },[])

    return(
        <div className="container-fluid">
            <h3> {params.category.toUpperCase()} PRODUCTS</h3>

            <section className="row">
                <nav className="col-2 overflow-auto" style={{height:'300px'}}>
                {
                    products.map(product=>
                        <div className="card p-2 m-2" style={{width:'100px'}}>
                            <Link to={`details/${product.id}`}>
                              <img src={product.image} className="card-img-top" height="50"/>
                            </Link>
                        </div>
                    )
                }
                 </nav>
                 <main className="col-10">
                        <Outlet />
                 </main>
            </section>

            <Link to="/">Back to Categories</Link>
        </div>
    )
}